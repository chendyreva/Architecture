package ru.geekbrains.client;

public class AuthException extends Exception{
}
